package com.example.sungho.chef;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class CookCustom2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cook_custom2);
    }
}
